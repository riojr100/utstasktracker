<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

include('header.php');

if (isset($_POST['login'])) {
    include('login_handler.php');
}

include('login_form.php');
include('footer.php');
