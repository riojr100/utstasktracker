<div id="add-task">
    <h2>Add Task</h2>
    <form action="task.php" method="post">
        <input type="text" name="task_name" placeholder="Task Name">
        <input type="submit" name="add_task" value="Add Task">
    </form>
</div>